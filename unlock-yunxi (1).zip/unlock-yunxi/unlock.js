const fs = require('fs');
const path = require('path');

// 过滤非法路径字符（Windows 不允许这些字符）
function safeName(name) {
  return name.replace(/[:\\\/\*\?"<>\|]/g, '_');
}

// 复制/解密单个文件（目前是直接拷贝，按需替换为实际解密逻辑）
function copyFile(src, destFile) {
  fs.mkdirSync(path.dirname(destFile), { recursive: true });
  const readStream = fs.createReadStream(src);
  const writeStream = fs.createWriteStream(destFile);
  readStream.pipe(writeStream);
  console.log(`文件已处理: ${src} -> ${destFile}`);
}

// 递归复制目录（会跳过 node_modules 和 uncode_ 前缀目录）
function copyDir(src, dest) {
  // 防止 dest 在 src 内部造成套娃
  if (path.resolve(dest).startsWith(path.resolve(src) + path.sep)) {
    console.warn(`警告: 目标目录 ${dest} 在源目录 ${src} 内，已跳过以防套娃。`);
    return;
  }

  if (!fs.existsSync(dest)) {
    fs.mkdirSync(dest, { recursive: true });
  }

  let items = fs.readdirSync(src);
  // 过滤解密输出生成的目录，防止重复进入
  items = items.filter(it => !it.startsWith('uncode_') && it !== 'node_modules');

  items.forEach((item, idx) => {
    let itemPath = path.join(src, item);
    let info = fs.statSync(itemPath);

    if (info.isDirectory()) {
      copyDir(itemPath, path.join(dest, item));
    } else if (info.isFile()) {
      const destFile = path.join(dest, item);
      copyFile(itemPath, destFile);
      console.log(`正在处理第 ${idx + 1} 个文件：${item}`);
    }
  });
}

// 入口：支持多个 src 参数，第二个参数可为指定的 destDir（也可为多个 src 时不传 dest）
const argv = process.argv.slice(2);
if (argv.length === 0) {
  console.error('用法: node unlock.js <srcPath1> [<srcPath2> ...] [destDir]');
  console.error('示例: node unlock.js "D:\\2" "D:\\4\\file.xlsx" "D:\\3"');
  process.exit(1);
}

// 如果最后一个参数是一个存在或者以盘符/\\起始的目录，我们当作 destDir。
// 简单判断：如果最后一个参数路径存在且是目录，或以驱动器盘符或 \\ 开头，则视为 dest 指定。
let destArg = null;
const maybeDest = argv[argv.length - 1];
if (argv.length >= 2) {
  const isAbsoluteLike = /^[a-zA-Z]:\\|^\\\\/.test(maybeDest);
  if (isAbsoluteLike || fs.existsSync(maybeDest) && fs.statSync(maybeDest).isDirectory()) {
    destArg = maybeDest;
    argv.pop(); // 把它当作 dest，剩下的作为 src 列表
  }
}

// 现在 argv 留下的都是 src 路径
const srcList = argv;

srcList.forEach(srcPathRaw => {
  const srcPath = srcPathRaw;
  if (!fs.existsSync(srcPath)) {
    console.error(`路径不存在: ${srcPath}`);
    return;
  }

  const base = safeName(path.basename(srcPath));
  // 目标：优先使用用户传入的 destArg；否则放到 srcPath 的同级（path.dirname）
  let finalDest;
  if (destArg) {
    // 如果 destArg 是文件（以存在且为文件），把它当目录处理
    let resolvedDest = path.resolve(destArg);
    try {
      if (fs.existsSync(resolvedDest) && fs.statSync(resolvedDest).isFile()) {
        resolvedDest = path.dirname(resolvedDest);
      }
    } catch (e) {}
    // 如果用户指定了一个具体目录，我们在其下再创建 uncode_base 子目录，避免和其他文件混淆
    finalDest = path.join(resolvedDest, `uncode_${base}`);
  } else {
    finalDest = path.join(path.dirname(srcPath), `uncode_${base}`);
  }

  // 防护：如果 finalDest 位于 srcPath 内，改到 finalDest_parent/uncode_base_timestamp
  if (path.resolve(finalDest).startsWith(path.resolve(srcPath) + path.sep)) {
    const altBase = `uncode_${base}_${Date.now()}`;
    finalDest = path.join(path.dirname(srcPath), altBase);
    console.warn(`目标目录在源目录内，已改为: ${finalDest}`);
  }

  // 创建并处理
  fs.mkdirSync(finalDest, { recursive: true });

  const stat = fs.statSync(srcPath);
  if (stat.isDirectory()) {
    copyDir(srcPath, finalDest);
  } else if (stat.isFile()) {
    const destFile = path.join(finalDest, path.basename(srcPath));
    copyFile(srcPath, destFile);
  } else {
    console.error(`既不是文件也不是目录: ${srcPath}`);
  }
});